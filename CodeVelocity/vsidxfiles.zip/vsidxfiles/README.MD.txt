Move these files to below path 

Use Git to move these files
C:\Users\Innovative Tech2\Documents\CodeVelocity\.vs\CodeVelocity\FileContentIndex